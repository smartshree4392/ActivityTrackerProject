const path = require("path");

const constructorMethod = app => {

  app.get("/home", (req, res) => {
    let events = [
      {
        "id" : "123",
        "name" : "Football",
        "description" : "Event to play football in Hoboken",
      },
      {
        "id" : "1234",
        "name" : "Cricket",
        "description" : "Event to play cricket in Hoboken",
      }
    ]

    res.render("layouts/main", {events:events});
  });

  app.get("/login", (req, res) => {
    res.render("layouts/login");
  });

  app.get("/createEvents", (req, res) => {
    res.render("layouts/createEvents");
  });

  app.get("/signup", (req, res) => {
    res.render("layouts/signup");
  });

  app.get("/myprofile", (req, res) => {
    res.render("layouts/profile");
  }); 

  app.post("/register", (req, res) =>
  {
    res.send({ "stat" : "registered" });
  });

  app.post("/addComment", (req, res) => {
    let body = req.body;
    let comment = body.comment;

    res.send(
        {
          "commentAdded" : "true",
          "username" : "Hem",
          "comment" : comment
        }
      );

  });

  app.get("/event", (req, res) => {
    let event = {
      "id" : "123",
      "name" : "Football",
      "description" : "Lorem ipsum dolor sit amet, consectetur adipisicing elit. A deserunt neque tempore recusandae animi soluta quasi? Asperiores rem dolore eaque vel, porro, soluta unde debitis aliquam laboriosam. Repellat explicabo, maiores! Lorem ipsum dolor sit amet, consectetur adipisicing elit. Omnis optio neque consectetur consequatur magni in nisi, natus beatae quidem quam odit commodi ducimus totam eum, alias, adipisci nesciunt voluptate. Voluptatum.",
      "date" : "12/11/2018",
      "time" : "9:00 pm - 10:00 pm",
      "addressLine1" : "Stevens Institute of Technology",
      "addressLine2" : "1 castle point",
      "city" : "Hoboken",
      "state" : "New Jersey",
      "zip" : "07306",
      "country" : "United States of America",
      "creatorPhone" : "2017724859",
      "creatorEmail" : "hshah42@stevens.edu"
    }
    res.render("layouts/event", {event : event});
  });

  app.get("/events", (req, res) => {
    let events = [
      {
        "id" : "123",
        "name" : "Football",
        "description" : "Event to play football in Hoboken",
      },
      {
        "id" : "1234",
        "name" : "Cricket",
        "description" : "Event to play cricket in Hoboken",
      }
    ]
    res.render("layouts/events", { events : events });
  });

};

module.exports = constructorMethod;